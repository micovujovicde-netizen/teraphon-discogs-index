#!/usr/bin/env python3
"""Validate all shards, remote byte-for-byte SHA-256, and budget before COMPLETE."""
import argparse
import hashlib
import json
from pathlib import Path
import sys


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def finalize(reports_dir, shards_dir, out_file, shards=16, max_bytes=5800000000, run_id='unknown'):
    reports_dir, shards_dir = Path(reports_dir), Path(shards_dir)
    reports = []
    sums = {'compressed_bytes':0, 'assigned_rows':0, 'unique_song_keys':0,
            'style_evidence':0,'genre_evidence':0}
    for num in range(shards):
        label = f'shard_{num:02d}'
        report_file = reports_dir / (label+'.json')
        obj = json.loads(report_file.read_text('utf-8'))
        if (obj.get('status'),obj.get('schema'),obj.get('shard'),obj.get('shard_count')) != ('shard_complete',2,num,shards):
            raise ValueError('Invalid report '+label)
        source = shards_dir / obj['compressed_name']
        if source.name != label+'.jsonl.zst' or not source.is_file():
            raise ValueError('Missing downloaded index '+label)
        if source.stat().st_size != obj['compressed_bytes'] or sha256_file(source) != obj['compressed_sha256']:
            raise ValueError('R2 download integrity verification failed for '+label)
        for k in sums:
            if k == 'compressed_bytes':
                sums[k] += obj['compressed_bytes']
            elif k == 'unique_song_keys':
                sums[k] += obj[k]
            else:
                sums[k] += obj['counters'].get(k,0)
        reports.append(obj)
    if len({r['input_source_sha256'] for r in reports}) != 1:
        raise ValueError('Shard source manifest SHA mismatch')
    if len({r['source_observations'] for r in reports}) != 1:
        raise ValueError('Shard source observation count mismatch')
    if len({r['parts_verified'] for r in reports}) != 1:
        raise ValueError('Shard part count mismatch')
    global_missing = {r['counters'].get('missing_key_global',0) for r in reports}
    if len(global_missing) != 1:
        raise ValueError('Missing artist/song count differs by shard')
    expected = reports[0]['source_observations'] - next(iter(global_missing))
    if sums['assigned_rows'] != expected:
        raise ValueError(f'Observation coverage mismatch {sums["assigned_rows"]} != {expected}')
    if sums['compressed_bytes'] > max_bytes:
        raise ValueError(f'Exceeded R2 5.8GB budget: {sums["compressed_bytes"]:,}')
    complete = {
        'status':'COMPLETE_AND_VERIFIED', 'schema':2, 'run_id':str(run_id),
        'source_manifest_sha256':reports[0]['input_source_sha256'],
        'source_observations':reports[0]['source_observations'],
        'observations_without_artist_or_song':next(iter(global_missing)),
        'parts_verified_per_shard':reports[0]['parts_verified'],
        'unique_artist_song_keys_global':sums['unique_song_keys'],
        'shards':shards, 'compressed_bytes':sums['compressed_bytes'],
        'max_compressed_bytes':max_bytes,
        'shard_objects':[{'name':r['compressed_name'], 'bytes':r['compressed_bytes'],
                          'sha256':r['compressed_sha256'], 'unique':r['unique_song_keys'],
                          'assigned_rows':r['counters']['assigned_rows']} for r in reports],
        'raw_archive_preserved':True,
        'warning':'Track year, style and genre are inferred from Discogs release-level evidence. Release provenance and original release IDs are not preserved in this compact index. Do not delete raw before keeping an independent backup if reprocessing may be needed.'
    }
    Path(out_file).write_text(json.dumps(complete, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({k:complete[k] for k in ('status','source_observations',
          'unique_artist_song_keys_global','compressed_bytes','max_compressed_bytes')},indent=2))
    return complete


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--reports-dir',required=True)
    p.add_argument('--shards-dir',required=True)
    p.add_argument('--out-file',required=True)
    p.add_argument('--shards',type=int,default=16)
    p.add_argument('--max-bytes',type=int,default=5800000000)
    p.add_argument('--run-id',default='unknown')
    a=p.parse_args()
    finalize(a.reports_dir,a.shards_dir,a.out_file,a.shards,a.max_bytes,a.run_id)


if __name__=='__main__':
    try:main()
    except Exception as e:
        print('FINALIZE FAILED:',e,file=sys.stderr)
        sys.exit(1)
