#!/usr/bin/env python3
"""TERAPHON One Movie: read-only Discogs CSV -> globally deduplicated compressed shards.

Each shard scans the COMPLETE archive; all observations of one normalized
(artist, song) key deterministically land in ONE shard. This avoids R2
intermediate files, keeping original+new index below the free-tier target.

No source R2 objects are ever removed/overwritten by this software.
"""
import argparse
import collections
import csv
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import sqlite3
import subprocess
import sys
import unicodedata

COLUMNS = ['artist', 'song', 'release_year', 'genres', 'styles', 'release_id',
           'master_id', 'release_title', 'country', 'formats', 'artist_source', 'year_source']


def normalize(s):
    s = unicodedata.normalize('NFKC', s or '')
    s = ''.join(c for c in s if unicodedata.category(c) != 'Cf')
    return ' '.join(s.casefold().split())


def song_key(a, t):
    a, t = normalize(a), normalize(t)
    if not a or not t:
        return None
    return hashlib.blake2b((a + '\0' + t).encode('utf-8'), digest_size=16).digest()


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def db_setup(db):
    db.executescript('''
        PRAGMA journal_mode=DELETE;
        PRAGMA synchronous=NORMAL;
        PRAGMA temp_store=FILE;
        PRAGMA cache_size=-32768;
        CREATE TABLE songs (
            k BLOB PRIMARY KEY, artist TEXT NOT NULL, song TEXT NOT NULL,
            first_year INTEGER, last_year INTEGER,
            observations INTEGER NOT NULL,
            ambiguous_observations INTEGER NOT NULL
        ) WITHOUT ROWID;
        CREATE TABLE styles (
            k BLOB NOT NULL, name TEXT NOT NULL, n INTEGER NOT NULL,
            PRIMARY KEY(k,name)
        ) WITHOUT ROWID;
        CREATE TABLE genres (
            k BLOB NOT NULL, name TEXT NOT NULL, n INTEGER NOT NULL,
            PRIMARY KEY(k,name)
        ) WITHOUT ROWID;
    ''')


SQL_SONG = '''INSERT INTO songs(k,artist,song,first_year,last_year,observations,ambiguous_observations)
    VALUES(?,?,?,?,?,1,?) ON CONFLICT(k) DO UPDATE SET
      first_year=CASE WHEN excluded.first_year IS NULL THEN songs.first_year
       WHEN songs.first_year IS NULL THEN excluded.first_year
       ELSE MIN(songs.first_year,excluded.first_year) END,
      last_year=CASE WHEN excluded.last_year IS NULL THEN songs.last_year
       WHEN songs.last_year IS NULL THEN excluded.last_year
       ELSE MAX(songs.last_year,excluded.last_year) END,
      observations=songs.observations+1,
      ambiguous_observations=songs.ambiguous_observations+excluded.ambiguous_observations'''
SQL_STYLE = '''INSERT INTO styles(k,name,n) VALUES(?,?,1)
    ON CONFLICT(k,name) DO UPDATE SET n=n+1'''
SQL_GENRE = '''INSERT INTO genres(k,name,n) VALUES(?,?,1)
    ON CONFLICT(k,name) DO UPDATE SET n=n+1'''


def valid_year(raw):
    raw = (raw or '').strip()
    if raw.isdecimal() and 1880 <= int(raw) <= 2100:
        return int(raw)
    return None


def export_jsonl_zstd(db, dest, level=15):
    """Ordered SQLite multi-cursor merge avoids millions of extra SQL queries."""
    styles_it = iter(db.execute('SELECT k,name,n FROM styles ORDER BY k'))
    genres_it = iter(db.execute('SELECT k,name,n FROM genres ORDER BY k'))
    style_next = next(styles_it, None)
    genre_next = next(genres_it, None)
    count, observation_count = 0, 0
    with open(dest, 'wb') as raw_out:
        p = subprocess.Popen(['zstd', '-q', '-T2', f'-{level}', '-c'], stdin=subprocess.PIPE, stdout=raw_out)
        try:
            for k, a, t, first, last, n, ambiguous in db.execute(
                    'SELECT k,artist,song,first_year,last_year,observations,ambiguous_observations FROM songs ORDER BY k'):
                sl = []
                while style_next is not None and style_next[0] == k:
                    sl.append([style_next[1], style_next[2]])
                    style_next = next(styles_it, None)
                gl = []
                while genre_next is not None and genre_next[0] == k:
                    gl.append([genre_next[1], genre_next[2]])
                    genre_next = next(genres_it, None)
                row = [a, t, first, last, n, ambiguous, sl, gl]
                p.stdin.write((json.dumps(row, ensure_ascii=False, separators=(',', ':')) + '\n').encode('utf-8'))
                count += 1
                observation_count += n
        finally:
            if p.stdin:
                p.stdin.close()
        if p.wait() != 0:
            raise RuntimeError('zstd compression failed')
    return count, observation_count


def index_shard(input_dir, out_dir, shard, shard_count, max_bytes,
                verify_hash=True, expect_complete=True):
    if not (0 <= shard < shard_count <= 256) or shard_count & (shard_count - 1):
        raise ValueError('Shard count must be a power of two, up to 256')
    source_dir, dest_dir = Path(input_dir), Path(out_dir)
    dest_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = source_dir/'STATE.json'
    manifest = json.loads(manifest_path.read_text('utf-8'))
    if manifest.get('schema') != 1 or (expect_complete and not manifest.get('complete')):
        raise ValueError('Source STATE.json not complete schema=1')
    parts = manifest['parts']
    if not parts or sum(int(x['rows']) for x in parts) != manifest['output_rows']:
        raise ValueError('Manifest part totals inconsistent')
    label = f'shard_{shard:02d}'
    sqlite_file = dest_dir / (label + '.sqlite')
    zst_file = dest_dir / (label + '.jsonl.zst')
    report_file = dest_dir / (label + '.json')
    for f in (sqlite_file, zst_file, report_file):
        if f.exists():
            raise FileExistsError(f'Refusing to overwrite: {f}')
    counters = collections.Counter()
    db = sqlite3.connect(str(sqlite_file))
    try:
        db_setup(db)
        for pidx, info in enumerate(parts, 1):
            fn = info['filename']
            if not re.fullmatch(r'part_\d{5}\.csv\.gz', fn):
                raise ValueError('Unsafe input filename '+repr(fn))
            path = source_dir / fn
            if not path.is_file():
                raise FileNotFoundError(path)
            if verify_hash and sha256_file(path) != info['sha256']:
                raise ValueError('SHA-256 mismatch in '+fn)
            before = counters['rows_scanned']
            with gzip.open(path, 'rt', encoding='utf-8', newline='') as f, db:
                reader = csv.DictReader(f)
                if reader.fieldnames != COLUMNS:
                    raise ValueError('CSV header mismatch in '+fn)
                for row in reader:
                    counters['rows_scanned'] += 1
                    a, t = row['artist'].strip(), row['song'].strip()
                    k = song_key(a, t)
                    if k is None:
                        counters['missing_key_global'] += 1
                        continue
                    if k[0] % shard_count != shard:
                        continue
                    year = valid_year(row['release_year'])
                    ambiguous = int(row['artist_source'] == 'ambiguous')
                    db.execute(SQL_SONG, (k, a, t, year, year, ambiguous))
                    counters['assigned_rows'] += 1
                    counters['ambiguous_rows'] += ambiguous
                    if year is None:
                        counters['unknown_year_rows'] += 1
                    for raw in row['styles'].split('|'):
                        style = raw.strip()
                        if style:
                            db.execute(SQL_STYLE, (k, style))
                            counters['style_evidence'] += 1
                    for raw in row['genres'].split('|'):
                        genre = raw.strip()
                        if genre:
                            db.execute(SQL_GENRE, (k, genre))
                            counters['genre_evidence'] += 1
            actual_rows = counters['rows_scanned'] - before
            if actual_rows != info['rows']:
                raise ValueError(f'Row count mismatch {fn}: {actual_rows} vs {info["rows"]}')
            if pidx % 20 == 0 or pidx == len(parts):
                print(f'{label}: {pidx}/{len(parts)} parts, {counters["assigned_rows"]:,} assigned rows', flush=True)
        if counters['rows_scanned'] != manifest['output_rows']:
            raise ValueError('Total scanned row count wrong')
        unique, counted_obs = export_jsonl_zstd(db, zst_file)
        if counted_obs != counters['assigned_rows']:
            raise ValueError('Exported observation counts do not match')
        size = zst_file.stat().st_size
        if size > max_bytes:
            raise ValueError(f'{label} exceeded {max_bytes:,} bytes ({size:,}); nothing uploaded')
        subprocess.run(['zstd', '-q', '-t', str(zst_file)], check=True)
        report = {
            'schema':2, 'status':'shard_complete', 'shard':shard, 'shard_count':shard_count,
            'input_source_sha256':sha256_file(manifest_path),
            'source_observations':manifest['output_rows'], 'parts_verified':len(parts),
            'compressed_name':zst_file.name, 'compressed_bytes':size,
            'compressed_sha256':sha256_file(zst_file),
            'unique_song_keys':unique,
            'counters':dict(counters),
            'data_format':'JSONL zstd: [display_artist,display_song,earliest_release_year,latest_release_year,observations,ambiguous_artist_observations,[[release_style,votes]...],[[release_genre,votes]...]]',
            'warning':'Release-level year/style/genre evidence; not verified original song year or song-specific style. Release IDs and per-release provenance omitted.'
        }
        report_file.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
        print(f'OK {label}: unique={unique:,}, observations={counted_obs:,}, compressed={size:,} bytes',flush=True)
        return report
    finally:
        db.close()
        if sqlite_file.exists():
            sqlite_file.unlink()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--input-dir', required=True)
    ap.add_argument('--out-dir', required=True)
    ap.add_argument('--shard', type=int, required=True)
    ap.add_argument('--shards', type=int, default=16)
    ap.add_argument('--max-bytes', type=int, default=362500000)
    ap.add_argument('--no-sha-check', action='store_true')
    args = ap.parse_args()
    index_shard(args.input_dir, args.out_dir, args.shard, args.shards, args.max_bytes, not args.no_sha_check)


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        print('ONE MOVIE SHARD FAILED:',e,file=sys.stderr)
        sys.exit(1)
