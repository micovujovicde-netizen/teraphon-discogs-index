import csv
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

PARENT = Path(__file__).resolve().parents[1]

def module_from(name, filename):
    spec = importlib.util.spec_from_file_location(name, PARENT/filename)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m

indexer = module_from('index_shard','index_shard.py')
finalizer = module_from('finalize', 'finalize.py')


def record(a, t, year, styles, genres, artist_source='track'):
    d = {k:'' for k in indexer.COLUMNS}
    d.update({'artist':a,'song':t,'release_year':str(year), 'styles':styles,
              'genres':genres,'artist_source':artist_source,'release_id':'1', 'year_source':'release'})
    return d


class PipelineTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.input = self.root/'input'
        self.input.mkdir()
        self.outs = []
        self.rows = [
            record('Alpha','Tune (Live)',1999,'Techno|House','Electronic'),
            record('Alpha','Tune (Live)',2005,'House','Electronic'),
            record('Alpha','Tune',2001,'Trance','Electronic'),
            record('Béta','Chanson',1998,'Jazz','Jazz'),
            record('Alpha','Tune (Live)',2002,'Techno','Electronic',artist_source='ambiguous'),
            record('Beta','Chanson','','Jazz','Jazz'),
            record('', 'Unknown', 2000, '', 'Electronic'),
        ]
        parts=[]
        for i,(lo,hi) in enumerate(((0,4),(4,7)),1):
            name = f'part_{i:05d}.csv.gz'
            path = self.input/name
            with gzip.open(path,'wt',encoding='utf-8',newline='') as f:
                writer = csv.DictWriter(f,fieldnames=indexer.COLUMNS)
                writer.writeheader()
                writer.writerows(self.rows[lo:hi])
            parts.append({'filename':name,'rows':hi-lo,'sha256':indexer.sha256_file(path)})
        (self.input/'STATE.json').write_text(json.dumps({'schema':1,'complete':True,'parts':parts,
                                   'output_rows':7}),encoding='utf-8')

    def tearDown(self):
        self.tmp.cleanup()

    def test_full_coverage_dedup_style_votes_and_finalization(self):
        all_rows=[]
        reports = self.root/'reports'
        shards_dir = self.root/'shards'
        reports.mkdir(); shards_dir.mkdir()
        for s in range(2):
            output = self.root/f'out{s}'
            r=indexer.index_shard(self.input,output,s,2,1000000)
            self.assertEqual(r['counters']['rows_scanned'],7)
            label=f'shard_{s:02d}'
            shutil.copy(output/(label+'.json'),reports/(label+'.json'))
            shutil.copy(output/(label+'.jsonl.zst'),shards_dir/(label+'.jsonl.zst'))
            raw=subprocess.check_output(['zstd','-dc',str(output/(label+'.jsonl.zst'))])
            all_rows += [json.loads(line) for line in raw.splitlines()]
        self.assertEqual(len(all_rows),4)  # Alpha live, Alpha studio, Béta, Beta
        self.assertEqual(sum(x[4] for x in all_rows),6)
        live=next(x for x in all_rows if x[0]=='Alpha' and x[1]=='Tune (Live)')
        self.assertEqual(live[2:6],[1999,2005,3,1])
        self.assertEqual(dict(live[6]), {'House':2,'Techno':2})
        complete=finalizer.finalize(reports,shards_dir,self.root/'COMPLETE.json',shards=2,max_bytes=1000000,run_id='test')
        self.assertEqual(complete['status'],'COMPLETE_AND_VERIFIED')
        self.assertEqual(complete['source_observations'],7)
        self.assertEqual(complete['observations_without_artist_or_song'],1)
        self.assertEqual(complete['unique_artist_song_keys_global'],4)
        self.assertTrue((self.input/'part_00001.csv.gz').is_file())

    def test_budget_blocks_and_source_is_untouched(self):
        with self.assertRaisesRegex(ValueError,'exceeded'):
            indexer.index_shard(self.input,self.root/'tiny',0,1,1)
        self.assertTrue((self.input/'STATE.json').is_file())
        self.assertFalse((self.root/'tiny'/'shard_00.json').exists())

    def test_qualifier_and_case_normalization(self):
        self.assertEqual(indexer.song_key('AlPhA',' TUNE '),indexer.song_key('alpha','tune'))
        self.assertNotEqual(indexer.song_key('Alpha','Tune'),indexer.song_key('Alpha','Tune (Live)'))

if __name__=='__main__':
    unittest.main()
