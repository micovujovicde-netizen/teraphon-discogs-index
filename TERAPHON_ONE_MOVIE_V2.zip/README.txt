TERAPHON — ONE MOVIE V2 (16 SHARDS, COMPACT ZSTD, R2 SAFE)

Upload this ZIP AS-IS to the ROOT of GitHub repo:
  micovujovicde-netizen/teraphon-discogs-index
Filename MUST remain:
  TERAPHON_ONE_MOVIE_V2.zip

Create one new workflow using the YAML inside this ZIP at exact path:
  .github/workflows/teraphon-discogs-one-movie.yml
(The ZIP is NOT automatically unpacked by GitHub; paste the workflow separately.)

The existing two GitHub Secrets are used; do not post them in chat.
Trigger workflow ONCE (workflow_dispatch, main).

WHAT IT DOES
* ONE GitHub click starts 16 parallel shards (at most 8 simultaneously).
* Every shard reads the full original raw R2 archive, but only indexes its
  deterministic 1/16 share of artist+song keys. This ensures all duplicate
  observations for a given artist/song are combined GLOBALLY.
* Every raw input file is checked against the SHA256 in STATE.json.
* Produces one compressed JSONL-zstd archive per shard with display artist,
  title, earliest/latest observed release years, observation counts, full
  release-style and release-genre evidence counts.
* None of the raw 1,157 files is deleted or changed.
* A hard maximum of 362,500,000 bytes is enforced for EACH shard BEFORE upload,
  for an aggregate shard budget of 5.8 BILLION bytes (5.8 GB, not 5.8 GiB).
* All 16 shards are downloaded back from R2 and SHA256 verified. The finishing
  job also verifies coverage and total size. Only then COMPLETE.json appears.

CLOUDFLARE R2 LOCATION
  Bucket: teraphon-music-data
  Original: raw/discogs-2026/
  New: index/one-movie-staging/<GITHUB_RUN_ID>/
  Marker: index/one-movie-staging/<GITHUB_RUN_ID>/COMPLETE.json

WARNING ABOUT THE 10GB FREE TIER
Original archive is ~3.71 decimal GB. New shards capped at 5.8 GB. This leaves
~0.49 GB of a 10GB decimal storage allotment, assuming no other R2 data.
A previous failed/incomplete run can leave staging files, increasing usage.
DON'T repeat full workflow blindly. It is not a hard storage block; extra
storage may be billed.

WARNING ABOUT DATA LOSS
The compact index retains aggregate per-song release-year bounds and counts of
styles and genres, not original release IDs, dates, country and formats. A
release's year/style is not guaranteed to be a song's first year/style.
If you ever delete original raw data, you lose ability to reconstruct those
provenance fields from this compact summary. KEEP A SECOND BACKUP of the raw
archive on an independent device before any deletion.

SIZE ESTIMATE
A 29,111-row pilot indicated ~2-3GB if compressibility generalizes. This
is only a projection, not a guarantee. Shards exceeding their per-shard
budget fail without uploading; raw data remains safe.

This ZIP is infrastructure/code only. It DOES NOT include 173 million songs.
