#!/usr/bin/env python3
"""TERAPHON Discogs *pilot* indexer; stdlib-only; read-only input.

Release rows are observations, not authoritative original song release dates.
The script deliberately limits itself to a small number of parts by default.
Never changes, deletes or rewrites the raw R2 archive.
"""
import argparse
import collections
import csv
import gzip
import hashlib
import json
from pathlib import Path
import re
import sqlite3
import sys
import unicodedata

COLUMNS = ['artist', 'song', 'release_year', 'genres', 'styles', 'release_id',
           'master_id', 'release_title', 'country', 'formats', 'artist_source', 'year_source']


def normalize(s):
    # Preserve scripts, accents, title qualifiers like (Live) and remix distinctions.
    s = unicodedata.normalize('NFKC', s or '')
    s = ''.join(c for c in s if unicodedata.category(c) != 'Cf')
    return ' '.join(s.casefold().split())


def key_for(artist, song):
    a, t = normalize(artist), normalize(song)
    if not a or not t: return None
    return hashlib.sha256((a + '\0' + t).encode('utf-8')).hexdigest()


def sha256_file(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def make_db(db):
    db.executescript('''
    PRAGMA journal_mode=WAL;
    PRAGMA synchronous=NORMAL;
    CREATE TABLE IF NOT EXISTS songs (
      key TEXT PRIMARY KEY, artist TEXT NOT NULL, song TEXT NOT NULL,
      artist_norm TEXT NOT NULL, song_norm TEXT NOT NULL,
      first_observed_release_year INTEGER, last_observed_release_year INTEGER,
      observations INTEGER NOT NULL DEFAULT 0,
      ambiguous_release_artist_observations INTEGER NOT NULL DEFAULT 0
    ) WITHOUT ROWID;
    CREATE TABLE IF NOT EXISTS release_style_evidence (
      key TEXT NOT NULL, style TEXT NOT NULL, observations INTEGER NOT NULL,
      PRIMARY KEY(key, style)
    ) WITHOUT ROWID;
    CREATE TABLE IF NOT EXISTS release_genre_evidence (
      key TEXT NOT NULL, genre TEXT NOT NULL, observations INTEGER NOT NULL,
      PRIMARY KEY(key, genre)
    ) WITHOUT ROWID;
    CREATE TABLE IF NOT EXISTS metadata(k TEXT PRIMARY KEY, v TEXT NOT NULL);
    ''')


def consume(reader, db, counters):
    song_insert = '''INSERT INTO songs(key,artist,song,artist_norm,song_norm,
      first_observed_release_year,last_observed_release_year,observations,ambiguous_release_artist_observations)
      VALUES (?,?,?,?,?,?,?,?,?) ON CONFLICT(key) DO UPDATE SET
      first_observed_release_year = CASE
        WHEN excluded.first_observed_release_year IS NULL THEN songs.first_observed_release_year
        WHEN songs.first_observed_release_year IS NULL THEN excluded.first_observed_release_year
        ELSE MIN(songs.first_observed_release_year,excluded.first_observed_release_year) END,
      last_observed_release_year = CASE
        WHEN excluded.last_observed_release_year IS NULL THEN songs.last_observed_release_year
        WHEN songs.last_observed_release_year IS NULL THEN excluded.last_observed_release_year
        ELSE MAX(songs.last_observed_release_year,excluded.last_observed_release_year) END,
      observations = songs.observations+1,
      ambiguous_release_artist_observations = songs.ambiguous_release_artist_observations+
        excluded.ambiguous_release_artist_observations'''
    style_insert = '''INSERT INTO release_style_evidence(key,style,observations) VALUES(?,?,1)
      ON CONFLICT(key,style) DO UPDATE SET observations=observations+1'''
    genre_insert = '''INSERT INTO release_genre_evidence(key,genre,observations) VALUES(?,?,1)
      ON CONFLICT(key,genre) DO UPDATE SET observations=observations+1'''
    for row in reader:
        counters['input_rows'] += 1
        artist, song = row['artist'].strip(), row['song'].strip()
        key = key_for(artist, song)
        if not key:
            counters['missing_artist_or_title'] += 1
            continue
        year = row['release_year'].strip()
        year = int(year) if year.isdecimal() and 1880 <= int(year) <= 2100 else None
        if year is None:
            counters['unknown_release_year'] += 1
        ambiguous = row['artist_source'] == 'ambiguous'
        if ambiguous:
            counters['ambiguous_artist_sources'] += 1
        db.execute(song_insert, (key,artist,song,normalize(artist),normalize(song),
                                 year,year,1,int(ambiguous)))
        counters['indexed_observations'] += 1
        for raw in row['styles'].split('|'):
            style = raw.strip()
            if style:
                db.execute(style_insert, (key,style))
                counters['style_evidence_occurrences'] += 1
        for raw in row['genres'].split('|'):
            genre = raw.strip()
            if genre:
                db.execute(genre_insert, (key,genre))
                counters['genre_evidence_occurrences'] += 1


def run(args):
    base = Path(args.input_dir)
    manifest = json.loads((base/'STATE.json').read_text('utf-8'))
    if manifest.get('schema') != 1 or not manifest.get('complete'):
        raise ValueError('STATE.json nije kompletan schema=1 katalog')
    all_parts = manifest.get('parts', [])
    if not all_parts:
        raise ValueError('STATE.json nema dijelova')
    if not args.allow_full and args.max_parts < 1:
        raise ValueError('Za cijeli katalog potreban je --allow-full; pilot je podrazumijevan.')
    parts = all_parts if args.allow_full else all_parts[:args.max_parts]
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    db_file = out/'pilot_index.sqlite'
    if db_file.exists():
        raise FileExistsError(f'Postojeći rezultat se ne prepisuje: {db_file}')
    db = sqlite3.connect(str(db_file))
    counters = collections.Counter()
    try:
        make_db(db)
        for partnum, item in enumerate(parts, 1):
            name = item['filename']
            if not re.fullmatch(r'part_\d{5}\.csv\.gz', name):
                raise ValueError(f'Neočekivano ime: {name}')
            p = base/name
            if not p.is_file(): raise FileNotFoundError(str(p))
            if args.verify_sha256 and sha256_file(p) != item['sha256']:
                raise ValueError(f'Pogrešan SHA-256: {name}')
            with gzip.open(p, 'rt', encoding='utf-8', newline='') as f:
                r = csv.DictReader(f)
                if r.fieldnames != COLUMNS:
                    raise ValueError(f'Neočekivane CSV kolone u {name}: {r.fieldnames}')
                with db:
                    before = counters['input_rows']
                    consume(r, db, counters)
            n = counters['input_rows'] - before
            if n != item['rows']:
                raise ValueError(f'Broj redova u {name}: {n} != {item["rows"]}')
            print(f'OK {partnum}/{len(parts)} {name}: {n:,} redova', flush=True)
        unique = db.execute('SELECT COUNT(*) FROM songs').fetchone()[0]
        style_top = db.execute('''SELECT style,SUM(observations) AS n
                    FROM release_style_evidence GROUP BY style ORDER BY n DESC LIMIT 40''').fetchall()
        genre_top = db.execute('''SELECT genre,SUM(observations) AS n
                    FROM release_genre_evidence GROUP BY genre ORDER BY n DESC LIMIT 30''').fetchall()
        report = {'status':'pilot_completed', 'schema':1,
            'source_release_count': manifest.get('completed_release_count'),
            'source_observation_count':manifest.get('output_rows'),
            'parts_processed':len(parts), 'parts_total':len(all_parts),
            'warning':'Godina i stil su iz IZDANJA. Ne dokaz originalne godine niti stila pojedinačne numere.',
            'normalization':'Unicode NFKC + casefold + whitespace; (Live)/(Remix) NOT erased',
            'unique_artist_song_keys_pilot':unique,
            'duplicates_within_pilot': counters['indexed_observations']-unique,
            'counters':dict(counters),
            'top_release_styles': [{'style':s,'observations':n} for s,n in style_top],
            'top_release_genres': [{'genre':s,'observations':n} for s,n in genre_top]}
        (out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
        db.execute("INSERT INTO metadata(k,v) VALUES('report',?)", (json.dumps(report,ensure_ascii=False),))
        db.commit()
        print('PILOT GOTOV: ',json.dumps({'parts':len(parts),'rows':counters['input_rows'],'unique':unique},ensure_ascii=False))
        return 0
    finally:
        db.close()


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--input-dir',required=True)
    ap.add_argument('--output-dir',required=True)
    ap.add_argument('--max-parts',type=int,default=1, help='Pilot: default samo jedan part')
    ap.add_argument('--verify-sha256',action='store_true')
    ap.add_argument('--allow-full',action='store_true',help='Samo za veliki server sa dovoljno resursa; ne koristiti na GH standard runneru')
    a=ap.parse_args()
    try: sys.exit(run(a))
    except Exception as e:
        print('NEUSPJEH:',e,file=sys.stderr);sys.exit(1)
