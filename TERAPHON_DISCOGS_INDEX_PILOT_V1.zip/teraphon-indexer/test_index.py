import csv
import gzip
import hashlib
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest
from index import COLUMNS, key_for, normalize, run

class Tests(unittest.TestCase):
    def test_unicode_and_variants(self):
        self.assertEqual(normalize('  ÉLÉMENT   '), 'élément')
        self.assertNotEqual(key_for('A', 'Song (Live)'), key_for('A','Song'))
        self.assertNotEqual(key_for('A','Song'), key_for('B','Song'))
    def test_index(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); base=root/'input';base.mkdir();out=root/'out'
            p=base/'part_00001.csv.gz'
            rows=[['Artist','Song','2001','Rock','Hard Rock','1','12','Release','UK','CD','track','release_year'],
                  ['artist','SONG','1999','Rock','Blues Rock','2','12','Reissue','UK','CD','track','release_year'],
                  ['Other','Song (Live)','','','', '3','','','', '', 'ambiguous','missing']]
            with gzip.open(p,'wt',encoding='utf-8',newline='') as f:
                w=csv.writer(f);w.writerow(COLUMNS);w.writerows(rows)
            manifest={'schema':1,'complete':True,'parts':[{'filename':p.name,'rows':3,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}],
                      'completed_release_count':3,'output_rows':3}
            (base/'STATE.json').write_text(json.dumps(manifest))
            a=type('A',(),{'input_dir':str(base),'output_dir':str(out),'max_parts':1,'verify_sha256':True,'allow_full':False})()
            self.assertEqual(run(a),0)
            report=json.loads((out/'report.json').read_text())
            self.assertEqual(report['unique_artist_song_keys_pilot'],2)
            self.assertEqual(report['duplicates_within_pilot'],1)
            db=sqlite3.connect(out/'pilot_index.sqlite')
            self.assertEqual(db.execute("SELECT first_observed_release_year FROM songs WHERE song='Song'").fetchone()[0],1999)
            db.close()
if __name__=='__main__':unittest.main()
