# TERAPHON DISCOGS INDEX — SAFE PILOT v1

**Status:** pilot source ready, **NOT DEPLOYED**, **NOT A SEARCH INDEX** for the complete catalogue.

## Why the pilot first?

The original data are 1,157 gzip/CSV parts + STATE.json in a **private** Cloudflare R2 bucket:

`teraphon-music-data/raw/discogs-2026/`

Manifest reports 19,575,942 Discogs releases and 173,308,263 observations. The data are **not** 173 million unique songs. A release's year is NOT guaranteed to be the original year of each recording; release styles are NOT confirmed per-song tags.

The free Cloudflare D1 plan allows **500 MB per database** and **100,000 written rows per day** (as of Nov 2026): do **not** blindly insert 173 million observations. See https://developers.cloudflare.com/d1/platform/limits/.

This pilot:
1. Downloads only `STATE.json` and `part_00001.csv.gz` in a GitHub Actions runner.
2. Validates SHA-256 of that part versus `STATE.json`.
3. Derives normalized **(artist,song)** keys (Unicode-aware, qualifiers preserved), stores observation counts, earliest **observed release year** (never label as 'original year'), and style/genre evidence tagged as release-level.
4. Produces a pilot SQLite file and `report.json` containing observed style/genre distributions and dedup ratio.
5. Uploads these reports as a temporary GitHub Actions artifact; **never writes to or deletes any R2 object**.

## How to use in GitHub

Workflow: `.github/workflows/teraphon-discogs-pilot.yml`

1. Place this project under the paths shown at repository root in a repository you control.
2. In **Repository Settings → Secrets and variables → Actions**, create:
   - `TERAPHON_R2_ACCESS_KEY_ID` — R2 S3 access key ID, NOT `cfut_...`
   - `TERAPHON_R2_SECRET_ACCESS_KEY` — R2 S3 secret access key.
3. Use a NEW **READ-ONLY** R2 token scoped only to `teraphon-music-data` if possible. Never paste credentials in code or screenshots.
4. The workflow must be on the repository's default branch to enable **Run workflow** in GitHub Actions.
5. Manually run **TERAPHON Discogs safe pilot**. Examine output artifact and `report.json`.

The script is self-contained (Python 3 stdlib, sqlite3) and also works with an offline directory.

## Next phase: entire catalogue, only after measuring pilot

Use the pilot to measure distinct artist/title ratio, key lengths, genre vocabulary and runtime. Then make a streaming partitioned batch (rather than a single enormous DB) and choose whether canonical lookups belong in sharded D1, R2 Data Catalog/Iceberg, or another data store. R2 SQL queries Iceberg tables, NOT raw CSV.GZ objects directly. Keep raw R2 as an immutable snapshot. Build a fast lookup API for batched 1,000-title queries. Assign `unclassified` when release-level evidence is ambiguous.

No edits to TERAPHON Android or existing playlist site in this project.
